public class Remember {
    public static void main(String args[]) {
        String firstLine = "Use \"\\\\\" to obtain a 'backslash' character.";

        System.out.println(firstLine);
        System.out.println("Remember:");
        System.out.println(firstLine);
    }
}